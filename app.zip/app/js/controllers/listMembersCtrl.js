'use strict';

app.controller('listMembersCtrl', ['$scope','loginService','generalServices', function($scope,loginService,generalServices){
	$scope.txt='/Inicio/Listar Membros';
	loginService.setMenus($scope);
	generalServices.listMembersLoadMembers($scope);
	generalServices.loadProfissoes($scope);
	generalServices.loadCategorias($scope);
	generalServices.loadIgreja($scope);
	var http = generalServices.getHttp();

	$scope.logout=function(){
		loginService.logout();
	},
	$scope.newMember=function(){
		generalServices.redirect("/newMember");
	},
    $scope.getNomes = function(val) {
      var pessoato = "{\"nomePessoa\":\""+val+"\"}";
      return http.post('http://localhost:8080/eventoscwb-war/rest/pessoa/autonotmember', pessoato).then(function(response){
        $scope.nomes = response.data;
        alert(JSON.parse(nomes));
      });
	},
	$scope.findByCpf = function(member){
		var pessoato = "{\"cpf\":\""+member.cpf+"\"}";
		return http.post('http://localhost:8080/eventoscwb-war/rest/pessoa/findbycpf', pessoato).then(function(response){
        $scope.member = response.data;
	  });
	} 


	//,	
	//$scope.loadingMembers=function(){
	//	var sessionto = "{\"codIgreja\":\""+sessionService.get('codigreja')+"\"}";
	//	var $retPessoas=$http.post('http://localhost:8080/eventoscwb-war/rest/pessoa/all',sessionto); //send data to backend java
	//	$retPessoas.then(function(msg){
//			var lstPessoas=msg.data;/
//			scope.pessoas = lstPessoas;
//		});
	//}

}])

