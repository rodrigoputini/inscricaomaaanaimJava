'use strict';
app.directive('loginDirective',function(){
	return{
		templateUrl:'partials/tpl/login.tpl.html'
	}

});