function customersController($scope,$http) {
  $http.get("http://localhost:8080/eventoscwb-war/rest/pessoa/all/")
  .success(function(response) {$scope.names = response;});
}
